# מאיה תור – הנחיות שילוב וסנכרון מלא באפליקציית Android (APK)

האפליקציה מחוברת ישירות ל-Firebase Firestore של מאיה תור:
- פרויקט: forward-reality-nbcxw
- מסד נתונים: ai-studio-e40e4022-63d4-43a4-87ea-21eeda7c1c3d
- אוסף רכבים (Collection): vehicles

---
### אפשרות א': הורדת פרויקט Android Studio שלם (מומלץ ביותר)
קובץ: MAYA_TOURS_Android_Studio_Complete.zip
1. חלץ את תוכן ה-ZIP אל תוך תיקיית מאגר ה-GitHub שלך (או פתח אותו ישירות ב-Android Studio).
2. הפרויקט מכיל כבר את כל קובצי הבנייה בנתיב app/src/main/assets/ ואת MainActivity.java המעודכן.
3. ב-GitHub תחת הלשונית Actions, הפעל את ה-Workflow "Build Android APK" והורד את ה-APK המעודכן!

---
### אפשרות ב': עדכון ידני של תיקיית assets ב-APK קיים
קובץ: maya-tour-apk-dist.zip
1. חלץ את הקבצים.
2. העתק את כל הקבצים ותיקיית assets אל תוך:
   app/src/main/assets/
3. וודא שב-MainActivity.java מוגדר:
   settings.setJavaScriptEnabled(true);
   settings.setDomStorageEnabled(true);
   settings.setDatabaseEnabled(true);
   settings.setAllowFileAccess(true);
   settings.setAllowUniversalAccessFromFileURLs(true);
   settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
4. בצע Build APK והתקן בטלפון.
