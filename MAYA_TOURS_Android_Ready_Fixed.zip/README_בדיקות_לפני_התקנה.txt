מאיה תור — גרסת Android עם WebViewAssetLoader

שינויים: MainActivity.java טוען קובצי assets באמצעות HTTPS מקומי (appassets.androidplatform.net), במקום file://. בוטלו הרשאות file access רחבות ותעבורת HTTP לא מוצפנת.

קוד Firebase מהחבילה המקורית נשמר ללא שינוי. projectId: forward-reality-nbcxw; databaseId: ai-studio-e40e4022-63d4-43a4-87ea-21eeda7c1c3d; collection: vehicles.

חשוב: לא בוצעה בניית APK בפועל או בדיקת כניסה/קריאה/כתיבה ל-Firestore. יש לבדוק ש-Firebase Authentication מאפשר את מקור WebView המקומי ושה-Firestore Rules אוכפים הרשאות. אם יש בעיית כניסה, יש לבדוק את אופן האימות; אין להחליש כללי אבטחה.

ב-GitHub: העלה את תוכן ה-ZIP לשורש המאגר תוך שמירה על נתיבי app/src/main/assets/assets. בדוק Actions. אל תסיר את האפליקציה הקיימת לפני גיבוי. APK debug עלול להיות חתום אחרת ולא להתקין מעל הקיים.
